Калькулятор
===========

Submodules
----------

calc.code module
------------------

.. automodule:: calc.code
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: calc
   :members:
   :undoc-members:
   :show-inheritance:
