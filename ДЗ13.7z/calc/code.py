#!/usr/bin/env python
# coding: utf-8

# In[ ]:


"""Калькулятор умеет вычитать слагать умножать и делить"""
def calculator():
    print('Приветствуем вас в калькуляторе Python')
    """Ввод чисел и операции"""
    input_one = float(input('Введите число 1: '))
    input_two = float(input('Введите число 2: '))
    operation = int(input('Какую операцию вы хотите выполнить? \n 1 Сложение \n 2 Вычитание \n 3 Деление \n 4 Умножение \n'))
    """Выбор действия"""
    if operation == 1:
        result = input_one + input_two
        operation_name = 'сложения'
    elif operation == 2:
        result = input_one - input_two
        operation_name = 'вычитания'
    elif operation == 3:
        result = input_one / input_two
        operation_name = 'деления'
    elif operation == 4:
        result = input_one * input_two
        operation_name = 'умножения'
        
    print('Результат', operation_name, '=', result)
    

calculator()

